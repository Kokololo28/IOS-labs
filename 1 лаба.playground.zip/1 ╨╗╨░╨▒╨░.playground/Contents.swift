import Foundation

var operation: String? = "+" // Можна вибрати операцію "+", "-", "*", або "/"
var num1: Double? = 10.5864
var num2: Double? = 0.0

func add(_ a: Double, _ b: Double) -> Double 
{
    return a + b
}

func subtract(_ a: Double, _ b: Double) -> Double 
{
    return a - b
}

func multiply(_ a: Double, _ b: Double) -> Double 
{
    return a * b
}

func divide(_ a: Double, _ b: Double) -> Double 
{
    if b != 0.0
    {
        return a / b
    } 
    else
    {
        print("Помилка: ділення на нуль")
        return 0.0
    }
}

if let operation = operation, let num1 = num1, let num2 = num2 
{
    var result: Double = 0.0

    switch operation 
    {
    case "+":
        result = add(num1, num2)
    case "-":
        result = subtract(num1, num2)
    case "*":
        result = multiply(num1, num2)
    case "/":
        result = divide(num1, num2)
        if num2 == 0.0 
        {
            break
        }
    default:
        print("Невідома операція")
    }

    if num2 != 0.0 
    {
        print("Результат: \(result)")
    }
} else 
{
    print("Змінні не були правильно ініціалізовані")
}
